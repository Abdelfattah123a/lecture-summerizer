package com.example.lecturesummarizer

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class SummaryActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_summary)

        val summaryText = intent.getStringExtra("pdfText") ?: ""
        findViewById<TextView>(R.id.summaryText).text = summaryText

        findViewById<Button>(R.id.continueBtn).setOnClickListener {
            val intent = Intent(this, QuestionActivity::class.java)
            intent.putExtra("summary", summaryText)
            startActivity(intent)
        }
    }
}