package com.example.lecturesummarizer

import android.content.Intent
import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AppCompatActivity

class QuestionActivity : AppCompatActivity() {
    data class Question(val question: String, val options: List<String>, val correct: Int)

    private val questions = listOf(
        Question("What is the topic?", listOf("A", "B", "C", "D"), 0),
        Question("What is the conclusion?", listOf("X", "Y", "Z", "W"), 1)
    )
    private var index = 0
    private var score = 0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_question)

        showQuestion()

        findViewById<Button>(R.id.nextBtn).setOnClickListener {
            val group = findViewById<RadioGroup>(R.id.optionsGroup)
            val selected = when (group.checkedRadioButtonId) {
                R.id.optionA -> 0
                R.id.optionB -> 1
                R.id.optionC -> 2
                R.id.optionD -> 3
                else -> -1
            }

            if (selected == questions[index].correct) score++
            index++
            if (index < questions.size) {
                showQuestion()
            } else {
                val intent = Intent(this, ResultActivity::class.java)
                intent.putExtra("score", score)
                intent.putExtra("total", questions.size)
                startActivity(intent)
            }
        }
    }

    private fun showQuestion() {
        val q = questions[index]
        findViewById<TextView>(R.id.questionText).text = q.question
        findViewById<RadioButton>(R.id.optionA).text = q.options[0]
        findViewById<RadioButton>(R.id.optionB).text = q.options[1]
        findViewById<RadioButton>(R.id.optionC).text = q.options[2]
        findViewById<RadioButton>(R.id.optionD).text = q.options[3]
    }
}